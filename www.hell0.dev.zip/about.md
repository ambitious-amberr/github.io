---
layout: page
title: About
---

This is my blog inspired by [worthdoingbadly.com](https://www.worthdoingbadly.com/).